﻿namespace Bloxstrap.Enums
{
    public enum BootstrapperIcon
    {
        IconBloxstrap,
        Icon2008,
        Icon2011,
        IconEarly2015,
        IconLate2015,
        Icon2017,
        Icon2019,
        Icon2022,
        IconCustom
    }
}
