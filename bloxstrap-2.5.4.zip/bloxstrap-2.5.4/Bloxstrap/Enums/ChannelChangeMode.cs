﻿namespace Bloxstrap.Enums
{
	public enum ChannelChangeMode
	{
		Automatic,
		Prompt,
		Ignore
	}
}
