﻿namespace Bloxstrap.Enums
{
    public enum CursorType
    {
        Default,
        From2006,
        From2013
    }
}
