﻿namespace Bloxstrap.Enums
{
    enum AssemblyLoadStatus
    {
        NotAttempted,
        Failed,
        Successful
    }
}
